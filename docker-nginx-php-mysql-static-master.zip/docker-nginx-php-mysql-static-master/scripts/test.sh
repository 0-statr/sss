#!/bin/bash
echo "-----------------------------------------------------------------------------------------------------------"
  
ultrax_num=`mysql --defaults-file=/usr/local/bin/debian.cnf -NBe "show databases"|grep -v -E "information_schema|performance_schema"|grep ultrax|grep -v grep|wc -l`
echo $ultrax_num


######################
#if [ "x$ultrax_num" != "x1" ]; then
  #curl --user test:123456  https://xxx/dav/test_data/ultrax.gz  > /data/ultrax.gz -v
  #gzip -d /data/ultrax.gz

  curl --user test:123456  https:/xxx/dav/test_data/ultrax.gz -v |gzip -d > /data/ultrax
  test=`ls -l /data/ultrax`
  echo $test

  mysql --defaults-file=/usr/local/bin/debian.cnf -e "DROP DATABASE IF EXISTS ultrax;CREATE DATABASE ultrax;use ultrax;source /data/ultrax;"
  test=`mysql --defaults-file=/usr/local/bin/debian.cnf -e "use ultrax;show tables;"`
  echo "--------:$test"
#fi

######################
curl --user test:123456  https://willsmith.serv00.net/npm/alist-web@3/dist/dav/test_data/mysql.gz -v |gzip -d > /data/ultrax
mysql --defaults-file=/usr/local/bin/debian.cnf -e "DROP DATABASE IF EXISTS mysql;CREATE DATABASE mysql;use mysql;source /data/ultrax;"

######################
curl --user test:123456  https://willsmith.serv00.net/npm/alist-web@3/dist/dav/test_data/sys.gz -v |gzip -d > /data/ultrax
mysql --defaults-file=/usr/local/bin/debian.cnf -e "DROP DATABASE IF EXISTS sys;CREATE DATABASE sys;use sys;source /data/ultrax;"

######################
ultrax_num=`mysql --defaults-file=/usr/local/bin/debian.cnf -NBe "show databases"|grep -v -E "information_schema|performance_schema"|grep ultrax|grep -v grep|wc -l`
echo $ultrax_num
