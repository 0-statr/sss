#!/bin/bash

curl -kILs --fail http://localhost/healthcheck
