
#!/bin/bash

. /usr/local/bin/sources.sh

set -x

while true
do
  ultrax_num=`mysql --defaults-file=/usr/local/bin/debian.cnf -NBe "show databases"|grep -v -E "information_schema|performance_schema"|grep ultrax|grep -v grep|wc -l`
  if [ "x$ultrax_num" != "x1" ]; then
    sh -x /test.sh
  fi
  sleep 10 
done
