#!/bin/bash
MYSQLDUMP_CURDATE=`date "+%Y%m%d_%H%M%S"`
echo "-----------------------------------------------------------------------------------------------------------"


test=`whoami`
echo $test
#######################################################3
mysqldump --defaults-file=/usr/local/bin/debian.cnf --single-transaction --routines --triggers --events "ultrax" | gzip -9 > "/data/ultrax.gz";
test=`ls -l /data/ultrax.gz`
echo $test
#test=`cat /data/ultrax.gz`
#echo $test

###
test=`curl --user test:123456 -T /data/ultrax.gz  https://xxx/dav/test_data/ultrax.${MYSQLDUMP_CURDATE}.gz -v`
test=`curl --user test:123456 -T /data/ultrax.gz  https://xxx/dav/test_data/ultrax.gz -v`

#######################################################3
mysqldump --defaults-file=/usr/local/bin/debian.cnf --single-transaction --routines --triggers --events "mysql" | gzip -9 > "/data/ultrax.gz";
test=`ls -l /data/ultrax.gz`
echo $test
#test=`cat /data/ultrax.gz`
#echo $test

###
test=`curl --user test:123456 -T /data/ultrax.gz  https://xxx/dav/test_data/mysql.${MYSQLDUMP_CURDATE}.gz -v`
test=`curl --user test:123456 -T /data/ultrax.gz  https://xxx/dav/test_data/mysql.gz -v`

#######################################################3
mysqldump --defaults-file=/usr/local/bin/debian.cnf --single-transaction --routines --triggers --events "sys" | gzip -9 > "/data/ultrax.gz";
test=`ls -l /data/ultrax.gz`
echo $test
#test=`cat /data/ultrax.gz`
#echo $test

###
test=`curl --user test:123456 -T /data/ultrax.gz  https://xxx/dav/test_data/sys.${MYSQLDUMP_CURDATE}.gz -v`
test=`curl --user test:123456 -T /data/ultrax.gz  https://xxx/dav/test_data/sys.gz -v`

exit 0
