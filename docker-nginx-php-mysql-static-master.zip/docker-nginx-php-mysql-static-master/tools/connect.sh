#!/bin/bash
docker exec -it httptest bash
