#!/bin/bash
docker stop httptest
docker rm -f httptest

